import React from "react"

const ErrorPages = () =>{
    return (
        <>    
         <div>
            <p>Error 404!</p>
        </div>
        </>

    )
}

export default ErrorPages