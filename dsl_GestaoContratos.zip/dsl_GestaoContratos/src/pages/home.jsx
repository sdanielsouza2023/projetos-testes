import './home.style.css'
function Home() {
    return (
        <>
            <div id={'header'}>
                header
            </div>
            <div id={'nav'}>
                nav
            </div>
            <div id={'main'}>
                main
            </div>
            <div id={'aside'}>
                aside
            </div>
            <div id={'footer'}>
                footer
            </div>
        </>
    )
}

export default Home;
