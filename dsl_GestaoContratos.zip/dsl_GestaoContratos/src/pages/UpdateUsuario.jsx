import React, { useState } from 'react';
import Input from '../components/form/input';
import './style_update_formulario.css';
import Button from '../components/Button';
import '../styles/globals.css';
import ProfileSection from '../components/ProfileSection/ProfileSection';

function UpdateUsuario() {
    const [nome, setNome] = useState('');
    const [senhaAtual, setSenhaAtual] = useState('');
    const [confirmarSenhaAtual, setConfirmarSenhaAtual] = useState('');
    const [link, setLink] = useState('');
  


    return (
        <div className='container'>
            <div className={'style_form'}>
                <ProfileSection>
                    <h3>Editar Dados</h3>
                </ProfileSection>
                <div className="input-button-container">
                    <Input
                        type="text"
                        text="Novo nome"
                        name="name"
                        placeholder="Insira seu nome."
                        handleOnChange={(e) => setNome(e.target.value)}
                    />
                </div>
                <div className="input-button-container">
                    <Input
                        type="password"
                        text="Senha Atual"
                        name="senhaAtual"
                        placeholder="Senha Atual"
                        handleOnChange={(e) => setSenhaAtual(e.target.value)}

                    />
                </div>
                <div className="input-button-container">
                    <Input
                        type="password"
                        text="Nova Senha"
                        name="confirmar-senha"
                        placeholder="Nova senha"
                        handleOnChange={(e) => setConfirmarSenhaAtual(e.target.value)}
                    />
                </div>
                <div className="input-button-container">
                    <Input
                        type="text"
                        text="Link Autentique"
                        name="link-autentique"
                        placeholder="Link Autentique:"
                        handleOnChange={(e) => setLink(e.target.value)}
                    />
                </div>
                <Button>Confirmar</Button>
            </div>
        </div>
    );
    }

export default UpdateUsuario;
