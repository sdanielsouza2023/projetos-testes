import React from 'react'
import ReactDOM from 'react-dom/client'
//import './styles/globals.css'
import App from './App.jsx'
import Login from './pages/Login_form.jsx'
import Cadastro from './pages/Cadastro_form.jsx'
import {
  createBrowserRouter, RouterProvider
} from 'react-router-dom'

import ErrorPages from './pages/ErrorPage.jsx'
import UpdateUsuario from './pages/UpdateUsuario.jsx'
import Home from './pages/home.jsx'
const router = createBrowserRouter([
  {
    path: "/",
    element:<App/>,
    errorElement: <ErrorPages/>,
    children:[
      {
        path:"/",
        element:<Login/>
      },
      {
        path: "cadastro",
        element: <Cadastro/>
        
      },{
        path:"update-usuario",
        element:<UpdateUsuario/>
      },{
        path:"home",
        element:<Home/>
      }
    ]
  },
])

ReactDOM.createRoot(document.getElementById('root')).render(
  <React.StrictMode>
   <RouterProvider router={router}/>
  </React.StrictMode>,
)
